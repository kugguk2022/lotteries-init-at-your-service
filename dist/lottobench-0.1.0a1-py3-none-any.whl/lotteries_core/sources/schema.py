"""Validation of retrieved draw history against a game's declared shape.

Bounds come from the :class:`~lotteries_core.protocol.GameSpec` rather than from literals, so a
source that starts returning out-of-range numbers after a rule change fails here instead of
silently poisoning a benchmark.
"""

from __future__ import annotations

import pandas as pd

from ..protocol import GameSpec

CANONICAL_COLUMNS = [
    "draw_date",
    "ball_1",
    "ball_2",
    "ball_3",
    "ball_4",
    "ball_5",
    "star_1",
    "star_2",
]


def expected_columns(spec: GameSpec) -> list[str]:
    """Canonical column order for a game: the date, then main balls, then any bonus pool."""
    columns = ["draw_date"]
    columns += [f"ball_{index + 1}" for index in range(spec.main_k)]
    columns += [f"star_{index + 1}" for index in range(spec.star_k)]
    return columns


def column_bounds(spec: GameSpec) -> dict[str, tuple[int, int]]:
    bounds = {f"ball_{index + 1}": (1, spec.main_n) for index in range(spec.main_k)}
    bounds.update({f"star_{index + 1}": (1, spec.star_n) for index in range(spec.star_k)})
    return bounds


def _validate_numeric_bounds(frame: pd.DataFrame, bounds: dict[str, tuple[int, int]]) -> None:
    """Raise ``ValueError`` when any column falls outside its configured inclusive interval."""
    for column, (low, high) in bounds.items():
        try:
            series = pd.to_numeric(frame[column], errors="raise").astype(int)
        except KeyError as exc:
            raise ValueError(f"Missing expected column: {column}") from exc
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Column {column} must contain numeric values") from exc

        if not ((series >= low) & (series <= high)).all():
            bad = series[(series < low) | (series > high)]
            raise ValueError(f"Column {column} contains out-of-range values: {list(bad)}")


def validate_frame(frame: pd.DataFrame, spec: GameSpec | None = None) -> pd.DataFrame:
    """Validate structure and ranges, returning a copy with naive timestamps and int columns."""
    spec = spec or GameSpec.euromillions()
    required = expected_columns(spec)
    missing = [name for name in required if name not in frame.columns]
    if missing:
        raise ValueError(f"Missing expected columns: {missing}")

    coerced = frame.copy()
    coerced["draw_date"] = pd.to_datetime(coerced["draw_date"], utc=True).dt.tz_convert(None)

    bounds = column_bounds(spec)
    _validate_numeric_bounds(coerced, bounds)
    # Cast only after the bound check, so downstream callers get consistent types and a failure
    # reports the offending value rather than an overflow.
    for column in bounds:
        coerced[column] = coerced[column].astype(int)
    return coerced


def finalize(frame: pd.DataFrame, spec: GameSpec | None = None) -> pd.DataFrame:
    """Validate, sort by draw date, and drop duplicate draws."""
    validated = validate_frame(frame, spec)
    return (
        validated.sort_values("draw_date")
        .drop_duplicates(subset=["draw_date"])
        .reset_index(drop=True)
    )
